const chalk = require("chalk");
const validator = require("validator");

console.log(chalk.green("Hello world"));

const res = validator.isEmail('thapa@thapa.com');
console.log(res?chalk.green.inverse(res):chalk.red.inverse(res));


(function(){
	var a ="vinod thapa";
	console.log(a);
})();

( function() {
	var a ="vinod thapa";
	console.log(a);
})();


