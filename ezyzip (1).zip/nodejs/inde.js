const fs=require("fs");
fs.writeFile("thapa/bio.txt","my name",(err)=>{
	console.log("folder created");
});