( function(){
var name="vinod";
console.log(name);
})();


