const path = require('path');
const express = require("express");
const app=express();
const port = process.env.port || 5000;


//Built in middleware

//
//to set the hbs
//app.set('view engine','hbs');

//app.use(express.static(staticPath));

app.get(" ",(req,res)=>{
	res.send("welcomw to thapa")
})


app.get("/about",(req,res)=>{
	res.send("hello for the about server")
})
app.get("/weather",(req,res)=>{
	res.send("hello for the weather server")
})
app.get("*",(req,res)=>{
	res.send("4042 error page oops")
})
app.listen(port,()=>{
	console.log(`listening to the port ${port}`)
})