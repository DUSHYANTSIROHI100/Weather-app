const oper = require("./oper");

console.log(oper);
console.log(oper.add(5,5));
console.log(oper.sub(10,5));

